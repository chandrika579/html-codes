
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/PHPMailerAutoload.php';
require 'vendor/vendor/autoload.php';

$mail = new PHPMailer(true);
$unique_identifier = uniqid();

if(isset($_POST['submit'])){
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];
    $subject = $_POST['subject'] . '-' . $unique_identifier ;

    $msg = "Hi, Greatings of the Day.<br><br>I am $fname $lname. I want to convey my request: $message<br><br>Thank you for considering my Application. I look forward to the possibility of discussing this exciting opportunity with you further.<br><br>Thanks and Regards,<br>$fname $lname<br>$email <br> $phone";  
    
    try {
        $mail->isSMTP();
        $mail->SMTPDebug = 2;   
        $mail->SMTPAuth = true;
        $mail->SMTPAutoTLS = false;
        $mail->SMTPSecure = "tls";
        $mail->Host = "smtp.hostinger.com";
        $mail->Port = 587;
        $mail->Username = "info@way2webit.com";
        $mail->Password = "Ultra.info!2024";
        
        $mail->setFrom('info@way2webit.com', 'learning');
        $mail->addAddress('kandulasainadh21@gmail.com', "Ultrakey IT Solutions Pvt. Ltd.");
        $mail->addReplyTo($_POST['email'], $email);
    
        // No attachment code here since we removed the file handling part
        
        $mail->isHTML(true);
        $mail->Phone = $phone;
        $mail->Subject = $subject;
        $mail->Body = $msg;
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
        echo "<script>alert('Email Sent Successfully');</script>";
        echo "<script>window.location ='index.html';</script>";
    } catch (Exception $e) {
        echo "<script>alert('Message could not be sent. Try Again')</script>";
        echo "<script>window.location.href='index.html';</script>";
    }
}
?>


